// Order status types
export type OrderStatus = "pending" | "preparing" | "ready" | "served"

// Table status types
export type TableStatus = "available" | "occupied"

// Menu item interface
export interface MenuItem {
  id: number
  name: string
  description: string
  price: number
  category: string
  image: string
}

// Order item interface
export interface OrderItem {
  name: string
  price: number
  status: OrderStatus
  quantity: number
}

// Order interface
export interface Order {
  id: number
  tableId: number
  items: OrderItem[]
  status: OrderStatus
  time: string
}

// Table interface
export interface Table {
  id: number
  status: TableStatus
  seats: number
  orders: {
    id: number
    items: string[]
    status: OrderStatus
    time: string
  }[]
}
