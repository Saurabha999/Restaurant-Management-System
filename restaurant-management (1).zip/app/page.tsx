import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ChefHat, Clock, Utensils, Users } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Utensils className="h-6 w-6 text-rose-600" />
            <h1 className="text-2xl font-bold">Gourmet Haven</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link
              href="/"
              className="font-medium text-slate-900 dark:text-white hover:text-rose-600 dark:hover:text-rose-400"
            >
              Home
            </Link>
            <Link
              href="/menu"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Menu
            </Link>
            <Link
              href="/about"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              About Us
            </Link>
            <Link
              href="/reservation"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Reservations
            </Link>
            <Link
              href="/staff"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Staff Portal
            </Link>
          </nav>
          <div className="flex space-x-2">
            <Button variant="outline" asChild>
              <Link href="/menu">View Menu</Link>
            </Button>
            <Button asChild>
              <Link href="/reservation">Reserve a Table</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <section className="text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Restaurant Management System</h2>
          <p className="text-xl text-slate-600 dark:text-slate-300 max-w-3xl mx-auto">
            A comprehensive solution for managing your restaurant operations, from orders to kitchen coordination.
          </p>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Utensils className="h-5 w-5 mr-2 text-rose-600" />
                Order Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-300">
                Efficiently manage customer orders from placement to service with real-time updates.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <ChefHat className="h-5 w-5 mr-2 text-rose-600" />
                Kitchen Interface
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-300">
                Streamlined kitchen view for chefs to manage preparation and coordinate with waitstaff.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2 text-rose-600" />
                Table Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-300">
                Track table occupancy and status in real-time to optimize seating and service.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2 text-rose-600" />
                Real-time Updates
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-slate-600 dark:text-slate-300">
                Instant status updates across all interfaces for seamless coordination.
              </p>
            </CardContent>
          </Card>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div>
            <h3 className="text-2xl font-bold mb-4">For Restaurant Staff</h3>
            <p className="text-slate-600 dark:text-slate-300 mb-4">
              Our system provides dedicated interfaces for waiters and kitchen staff, enabling efficient communication
              and order management.
            </p>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-rose-100 dark:bg-rose-900 p-2 rounded-full mr-4">
                  <Utensils className="h-5 w-5 text-rose-600 dark:text-rose-300" />
                </div>
                <div>
                  <h4 className="font-medium">Waiter Interface</h4>
                  <p className="text-slate-600 dark:text-slate-300">
                    Take orders, update statuses, and manage tables with ease.
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-rose-100 dark:bg-rose-900 p-2 rounded-full mr-4">
                  <ChefHat className="h-5 w-5 text-rose-600 dark:text-rose-300" />
                </div>
                <div>
                  <h4 className="font-medium">Kitchen Dashboard</h4>
                  <p className="text-slate-600 dark:text-slate-300">
                    View incoming orders, update preparation status, and coordinate with waitstaff.
                  </p>
                </div>
              </div>
            </div>
            <Button className="mt-6" asChild>
              <Link href="/staff">Access Staff Portal</Link>
            </Button>
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-4">For Customers</h3>
            <p className="text-slate-600 dark:text-slate-300 mb-4">
              Customers can browse the menu, place orders, and enjoy a seamless dining experience.
            </p>
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-rose-100 dark:bg-rose-900 p-2 rounded-full mr-4">
                  <Users className="h-5 w-5 text-rose-600 dark:text-rose-300" />
                </div>
                <div>
                  <h4 className="font-medium">Digital Menu</h4>
                  <p className="text-slate-600 dark:text-slate-300">
                    Browse our menu with detailed descriptions and images.
                  </p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="bg-rose-100 dark:bg-rose-900 p-2 rounded-full mr-4">
                  <Clock className="h-5 w-5 text-rose-600 dark:text-rose-300" />
                </div>
                <div>
                  <h4 className="font-medium">Table Reservations</h4>
                  <p className="text-slate-600 dark:text-slate-300">
                    Reserve your table online with our easy-to-use reservation system.
                  </p>
                </div>
              </div>
            </div>
            <div className="flex space-x-4 mt-6">
              <Button asChild>
                <Link href="/menu">View Menu</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/reservation">Reserve a Table</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Utensils className="h-6 w-6 text-rose-400" />
              <h2 className="text-xl font-bold">Gourmet Haven</h2>
            </div>
            <div className="flex space-x-6">
              <Link href="/" className="text-slate-300 hover:text-white">
                Home
              </Link>
              <Link href="/menu" className="text-slate-300 hover:text-white">
                Menu
              </Link>
              <Link href="/about" className="text-slate-300 hover:text-white">
                About Us
              </Link>
              <Link href="/reservation" className="text-slate-300 hover:text-white">
                Reservations
              </Link>
              <Link href="/staff" className="text-slate-300 hover:text-white">
                Staff Portal
              </Link>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>© {new Date().getFullYear()} Gourmet Haven Restaurant Management System. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
