import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Skeleton className="h-6 w-6 rounded-full" />
            <Skeleton className="h-8 w-32" />
          </div>
          <nav className="hidden md:flex space-x-6">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-6 w-20" />
            ))}
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Skeleton className="h-10 w-10 rounded-md mr-4" />
          <Skeleton className="h-10 w-48" />
        </div>

        {/* Restaurant Story Section */}
        <section className="mb-16">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <Skeleton className="h-10 w-48 mb-4" />
              <div className="space-y-4">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
              </div>
            </div>
            <Skeleton className="h-[400px] w-full rounded-lg" />
          </div>
        </section>

        {/* Chef Bio Section */}
        <Skeleton className="h-[500px] w-full rounded-lg mb-16" />

        {/* Team Section */}
        <section className="mb-16">
          <Skeleton className="h-10 w-48 mx-auto mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-[400px] w-full rounded-lg" />
            ))}
          </div>
        </section>

        {/* Mission Section */}
        <Skeleton className="h-[300px] w-full rounded-lg mb-16" />

        {/* Call to Action */}
        <section className="text-center mb-16">
          <Skeleton className="h-10 w-96 mx-auto mb-4" />
          <Skeleton className="h-4 w-full max-w-2xl mx-auto mb-6" />
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Skeleton className="h-12 w-48 rounded-md" />
            <Skeleton className="h-12 w-48 rounded-md" />
          </div>
        </section>
      </main>

      <Skeleton className="h-[300px] w-full" />
    </div>
  )
}
