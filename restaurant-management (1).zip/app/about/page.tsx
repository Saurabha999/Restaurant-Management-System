import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ChevronLeft, Facebook, Instagram, Utensils, Twitter } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Utensils className="h-6 w-6 text-rose-600" />
            <h1 className="text-2xl font-bold">Gourmet Haven</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link
              href="/"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Home
            </Link>
            <Link
              href="/menu"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Menu
            </Link>
            <Link
              href="/about"
              className="font-medium text-slate-900 dark:text-white hover:text-rose-600 dark:hover:text-rose-400"
            >
              About Us
            </Link>
            <Link
              href="/reservation"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Reservations
            </Link>
            <Link
              href="/staff"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Staff Portal
            </Link>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Link href="/" className="mr-4">
            <Button variant="outline" size="icon">
              <ChevronLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h2 className="text-3xl font-bold">About Us</h2>
        </div>

        {/* Restaurant Story Section */}
        <section className="mb-16">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold mb-4">Our Story</h3>
              <div className="space-y-4 text-slate-700 dark:text-slate-300">
                <p>
                  Gourmet Haven was born from a passion for exceptional food and memorable dining experiences. Founded
                  in 2010 by Chef Isabella Martinez, our restaurant began as a small bistro with just eight tables in
                  the heart of the city.
                </p>
                <p>
                  What started as a humble venture quickly gained recognition for its innovative cuisine and warm
                  atmosphere. As word spread about our unique culinary approach that blends traditional techniques with
                  modern creativity, we expanded to our current location in 2015.
                </p>
                <p>
                  Today, Gourmet Haven stands as a culinary landmark, serving thousands of guests each year while
                  maintaining the intimate, personalized experience that made us special from day one. Our journey
                  continues as we explore new flavors, refine our craft, and create unforgettable moments for our
                  guests.
                </p>
              </div>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Restaurant interior"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </section>

        {/* Chef Bio Section */}
        <section className="mb-16 bg-white dark:bg-slate-800 rounded-lg p-8">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="order-2 md:order-1">
              <h3 className="text-2xl font-bold mb-4">Meet Our Executive Chef</h3>
              <h4 className="text-xl text-rose-600 mb-2">Chef Isabella Martinez</h4>
              <div className="space-y-4 text-slate-700 dark:text-slate-300">
                <p>
                  With over 20 years of culinary experience spanning three continents, Chef Isabella brings a world of
                  flavor to every dish at Gourmet Haven. Her journey began in her grandmother's kitchen in Barcelona,
                  where she learned the importance of fresh ingredients and traditional techniques.
                </p>
                <p>
                  After training at the prestigious Culinary Institute of Paris, Isabella worked in Michelin-starred
                  restaurants across Europe before bringing her talents to our city. Her philosophy centers on
                  respecting ingredients while pushing boundaries to create unexpected flavor combinations.
                </p>
                <p>
                  "Food is a universal language that brings people together. At Gourmet Haven, we speak this language
                  with passion, precision, and creativity," says Chef Isabella, whose seasonal menus have earned
                  critical acclaim and a devoted following.
                </p>
              </div>
            </div>
            <div className="relative h-[400px] rounded-full overflow-hidden order-1 md:order-2 max-w-[400px] mx-auto">
              <Image
                src="/placeholder.svg?height=400&width=400"
                alt="Chef Isabella Martinez"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="mb-16">
          <h3 className="text-2xl font-bold mb-8 text-center">Our Culinary Team</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                name: "Marco Rodriguez",
                role: "Sous Chef",
                bio: "Specializing in seafood dishes, Marco brings 15 years of experience and a passion for sustainable fishing practices.",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "Sophia Chen",
                role: "Pastry Chef",
                bio: "Award-winning pastry artist whose innovative desserts combine traditional techniques with modern presentation.",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "James Wilson",
                role: "Sommelier",
                bio: "Certified sommelier with an exceptional talent for pairing wines with our seasonal menu offerings.",
                image: "/placeholder.svg?height=300&width=300",
              },
              {
                name: "Olivia Thompson",
                role: "Restaurant Manager",
                bio: "The orchestrator of our dining experience, ensuring every guest receives impeccable service and attention.",
                image: "/placeholder.svg?height=300&width=300",
              },
            ].map((member, index) => (
              <Card key={index} className="overflow-hidden">
                <div className="relative h-64">
                  <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle>{member.name}</CardTitle>
                  <CardDescription className="text-rose-600">{member.role}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-700 dark:text-slate-300">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Mission Section */}
        <section className="mb-16 bg-rose-50 dark:bg-rose-900/20 rounded-lg p-8">
          <div className="max-w-3xl mx-auto text-center">
            <h3 className="text-2xl font-bold mb-6">Our Mission</h3>
            <p className="text-xl mb-8 text-slate-700 dark:text-slate-300">
              "To create extraordinary culinary experiences that nourish both body and soul, while honoring the
              traditions of global cuisine and supporting our local community."
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">Quality</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-slate-700 dark:text-slate-300">
                    We source the finest ingredients, prioritizing local and sustainable options to ensure exceptional
                    quality in every dish.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">Creativity</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-slate-700 dark:text-slate-300">
                    We embrace innovation while respecting culinary traditions, creating unique dishes that surprise and
                    delight.
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle className="text-center">Community</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-slate-700 dark:text-slate-300">
                    We foster meaningful connections with our guests, staff, and community partners, creating a
                    welcoming environment for all.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="text-center mb-16">
          <h3 className="text-2xl font-bold mb-4">Join Us for an Unforgettable Dining Experience</h3>
          <p className="mb-6 max-w-2xl mx-auto text-slate-700 dark:text-slate-300">
            We invite you to be part of our story. Whether you're celebrating a special occasion or simply enjoying a
            meal with loved ones, we look forward to serving you.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" asChild>
              <Link href="/reservation">Make a Reservation</Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/menu">View Our Menu</Link>
            </Button>
          </div>
        </section>
      </main>

      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Utensils className="h-6 w-6 text-rose-400" />
                <h2 className="text-xl font-bold">Gourmet Haven</h2>
              </div>
              <p className="text-slate-300 mb-4">
                123 Culinary Street
                <br />
                Foodie District
                <br />
                Cityville, CV 12345
              </p>
              <p className="text-slate-300">
                Phone: (555) 123-4567
                <br />
                Email: info@gourmethaven.com
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Hours</h3>
              <p className="text-slate-300 mb-2">Monday - Thursday: 11am - 10pm</p>
              <p className="text-slate-300 mb-2">Friday - Saturday: 11am - 11pm</p>
              <p className="text-slate-300">Sunday: 10am - 9pm</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Connect With Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-white hover:text-rose-400 transition-colors">
                  <Facebook className="h-6 w-6" />
                  <span className="sr-only">Facebook</span>
                </a>
                <a href="#" className="text-white hover:text-rose-400 transition-colors">
                  <Instagram className="h-6 w-6" />
                  <span className="sr-only">Instagram</span>
                </a>
                <a href="#" className="text-white hover:text-rose-400 transition-colors">
                  <Twitter className="h-6 w-6" />
                  <span className="sr-only">Twitter</span>
                </a>
              </div>
              <div className="mt-4">
                <Button variant="outline" className="border-white text-white hover:text-rose-400" asChild>
                  <Link href="/reservation">Make a Reservation</Link>
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>© {new Date().getFullYear()} Gourmet Haven Restaurant. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
