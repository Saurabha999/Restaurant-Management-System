"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChefHat, ChevronLeft, Utensils } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function StaffLoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [role, setRole] = useState("waiter")
  const router = useRouter()
  const { toast } = useToast()

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault()

    // In a real app, this would validate credentials against a backend
    if (username && password) {
      // Simulate successful login
      if (role === "waiter") {
        router.push("/staff/waiter")
      } else if (role === "kitchen") {
        router.push("/staff/kitchen")
      }
    } else {
      toast({
        title: "Login failed",
        description: "Please enter both username and password",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-6 flex items-center">
          <Link href="/" className="flex items-center space-x-2">
            <Utensils className="h-6 w-6 text-rose-600" />
            <h1 className="text-2xl font-bold">Gourmet Haven</h1>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <div className="flex items-center mb-2">
              <Link href="/" className="mr-4">
                <Button variant="outline" size="icon">
                  <ChevronLeft className="h-4 w-4" />
                </Button>
              </Link>
              <CardTitle className="text-2xl">Staff Login</CardTitle>
            </div>
            <CardDescription>Enter your credentials to access the staff portal</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label>Select your role</Label>
                <Tabs defaultValue="waiter" onValueChange={setRole} className="w-full">
                  <TabsList className="grid grid-cols-2">
                    <TabsTrigger value="waiter" className="flex items-center">
                      <Utensils className="h-4 w-4 mr-2" />
                      Waiter
                    </TabsTrigger>
                    <TabsTrigger value="kitchen" className="flex items-center">
                      <ChefHat className="h-4 w-4 mr-2" />
                      Kitchen
                    </TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>

              <Button type="submit" className="w-full">
                Login
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              For demonstration purposes, any username and password will work
            </p>
          </CardFooter>
        </Card>
      </main>
    </div>
  )
}
