"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Bell, ChefHat, Clock, LogOut, Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"

// Sample data for orders
const initialOrders = [
  {
    id: 101,
    tableId: 2,
    items: [
      { name: "Grilled Salmon", price: 24.99, status: "served" },
      { name: "Tiramisu", price: 8.99, status: "served" },
    ],
    status: "served",
    time: "18:30",
  },
  {
    id: 102,
    tableId: 3,
    items: [
      { name: "Bruschetta", price: 8.99, status: "preparing" },
      { name: "Beef Tenderloin", price: 32.99, status: "preparing" },
      { name: "Chocolate Lava Cake", price: 9.99, status: "pending" },
    ],
    status: "preparing",
    time: "18:45",
  },
  {
    id: 103,
    tableId: 5,
    items: [
      { name: "Calamari", price: 12.99, status: "pending" },
      { name: "Mushroom Risotto", price: 18.99, status: "pending" },
      { name: "Wine", price: 9.99, status: "pending" },
    ],
    status: "pending",
    time: "19:00",
  },
]

export default function KitchenDashboard() {
  const [orders, setOrders] = useState(initialOrders)
  const [activeTab, setActiveTab] = useState("pending")
  const [searchQuery, setSearchQuery] = useState("")
  const { toast } = useToast()

  const filteredOrders = orders.filter((order) => {
    // Filter by status tab
    if (activeTab !== "all" && order.status !== activeTab) return false

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      const orderIdMatch = order.id.toString().includes(query)
      const tableIdMatch = order.tableId.toString().includes(query)
      const itemsMatch = order.items.some((item) => item.name.toLowerCase().includes(query))

      return orderIdMatch || tableIdMatch || itemsMatch
    }

    return true
  })

  const handleOrderStatusChange = (orderId: number, newStatus: string) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order)))

    toast({
      title: `Order #${orderId} status updated`,
      description: `Order status changed to ${newStatus}`,
    })
  }

  const handleItemStatusChange = (orderId: number, itemName: string, newStatus: string) => {
    setOrders(
      orders.map((order) => {
        if (order.id === orderId) {
          const updatedItems = order.items.map((item) =>
            item.name === itemName ? { ...item, status: newStatus } : item,
          )

          // Check if all items are in the same status
          const allItemsStatus = updatedItems.every((item) => item.status === newStatus)

          return {
            ...order,
            items: updatedItems,
            // Update order status if all items have the same status
            status: allItemsStatus ? newStatus : order.status,
          }
        }
        return order
      }),
    )

    toast({
      title: `Item status updated`,
      description: `${itemName} status changed to ${newStatus}`,
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "preparing":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "ready":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "served":
        return "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300"
      default:
        return "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300"
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <ChefHat className="h-6 w-6 text-rose-600" />
            <h1 className="text-xl font-bold">Kitchen Dashboard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="icon">
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            <Link href="/staff">
              <Button variant="outline" size="icon">
                <LogOut className="h-5 w-5" />
                <span className="sr-only">Logout</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold">Kitchen Orders</h2>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search orders..."
                className="pl-8 w-[200px]"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        <Tabs defaultValue="pending" onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="pending">Pending</TabsTrigger>
            <TabsTrigger value="preparing">Preparing</TabsTrigger>
            <TabsTrigger value="ready">Ready</TabsTrigger>
            <TabsTrigger value="served">Served</TabsTrigger>
            <TabsTrigger value="all">All Orders</TabsTrigger>
          </TabsList>

          <TabsContent value="pending" className="mt-0">
            <OrdersList
              orders={filteredOrders}
              onOrderStatusChange={handleOrderStatusChange}
              onItemStatusChange={handleItemStatusChange}
              getStatusColor={getStatusColor}
            />
          </TabsContent>

          <TabsContent value="preparing" className="mt-0">
            <OrdersList
              orders={filteredOrders}
              onOrderStatusChange={handleOrderStatusChange}
              onItemStatusChange={handleItemStatusChange}
              getStatusColor={getStatusColor}
            />
          </TabsContent>

          <TabsContent value="ready" className="mt-0">
            <OrdersList
              orders={filteredOrders}
              onOrderStatusChange={handleOrderStatusChange}
              onItemStatusChange={handleItemStatusChange}
              getStatusColor={getStatusColor}
            />
          </TabsContent>

          <TabsContent value="served" className="mt-0">
            <OrdersList
              orders={filteredOrders}
              onOrderStatusChange={handleOrderStatusChange}
              onItemStatusChange={handleItemStatusChange}
              getStatusColor={getStatusColor}
            />
          </TabsContent>

          <TabsContent value="all" className="mt-0">
            <OrdersList
              orders={filteredOrders}
              onOrderStatusChange={handleOrderStatusChange}
              onItemStatusChange={handleItemStatusChange}
              getStatusColor={getStatusColor}
            />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

// OrdersList component to avoid repetition
function OrdersList({
  orders,
  onOrderStatusChange,
  onItemStatusChange,
  getStatusColor,
}: {
  orders: any[]
  onOrderStatusChange: (orderId: number, status: string) => void
  onItemStatusChange: (orderId: number, itemName: string, status: string) => void
  getStatusColor: (status: string) => string
}) {
  if (orders.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-8">
          <p className="text-slate-500 dark:text-slate-400">No orders found</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {orders.map((order) => (
        <Card key={order.id}>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center">
                <Clock className="h-4 w-4 mr-2" />
                Order #{order.id}
              </CardTitle>
              <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
            </div>
            <CardDescription>
              Table {order.tableId} - {order.time}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {order.items.map((item: any, index: number) => (
                <div key={index} className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">{item.name}</p>
                  </div>
                  <Select
                    defaultValue={item.status}
                    onValueChange={(value) => onItemStatusChange(order.id, item.name, value)}
                  >
                    <SelectTrigger className="w-[120px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="preparing">Preparing</SelectItem>
                      <SelectItem value="ready">Ready</SelectItem>
                      <SelectItem value="served">Served</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <Select defaultValue={order.status} onValueChange={(value) => onOrderStatusChange(order.id, value)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Update order status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="preparing">Preparing</SelectItem>
                <SelectItem value="ready">Ready for Service</SelectItem>
                <SelectItem value="served">Served</SelectItem>
              </SelectContent>
            </Select>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}
