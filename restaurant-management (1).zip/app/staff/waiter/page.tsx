"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Bell, Clock, LogOut, Plus, Search, Utensils } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

// Sample data for tables
const initialTables = [
  { id: 1, status: "available", seats: 2, orders: [] },
  {
    id: 2,
    status: "occupied",
    seats: 4,
    orders: [{ id: 101, items: ["Grilled Salmon", "Tiramisu"], status: "served", time: "18:30" }],
  },
  {
    id: 3,
    status: "occupied",
    seats: 6,
    orders: [
      { id: 102, items: ["Bruschetta", "Beef Tenderloin", "Chocolate Lava Cake"], status: "preparing", time: "18:45" },
    ],
  },
  { id: 4, status: "available", seats: 4, orders: [] },
  {
    id: 5,
    status: "occupied",
    seats: 2,
    orders: [{ id: 103, items: ["Calamari", "Mushroom Risotto", "Wine"], status: "pending", time: "19:00" }],
  },
  { id: 6, status: "available", seats: 8, orders: [] },
]

// Sample data for orders
const initialOrders = [
  {
    id: 101,
    tableId: 2,
    items: [
      { name: "Grilled Salmon", price: 24.99, status: "served" },
      { name: "Tiramisu", price: 8.99, status: "served" },
    ],
    status: "served",
    time: "18:30",
  },
  {
    id: 102,
    tableId: 3,
    items: [
      { name: "Bruschetta", price: 8.99, status: "preparing" },
      { name: "Beef Tenderloin", price: 32.99, status: "preparing" },
      { name: "Chocolate Lava Cake", price: 9.99, status: "pending" },
    ],
    status: "preparing",
    time: "18:45",
  },
  {
    id: 103,
    tableId: 5,
    items: [
      { name: "Calamari", price: 12.99, status: "pending" },
      { name: "Mushroom Risotto", price: 18.99, status: "pending" },
      { name: "Wine", price: 9.99, status: "pending" },
    ],
    status: "pending",
    time: "19:00",
  },
]

// Menu data for adding new orders
const menuItems = [
  {
    id: 1,
    name: "Bruschetta",
    price: 8.99,
    category: "appetizers",
  },
  {
    id: 2,
    name: "Calamari",
    price: 12.99,
    category: "appetizers",
  },
  {
    id: 3,
    name: "Grilled Salmon",
    price: 24.99,
    category: "main-courses",
  },
  {
    id: 4,
    name: "Beef Tenderloin",
    price: 32.99,
    category: "main-courses",
  },
  {
    id: 5,
    name: "Mushroom Risotto",
    price: 18.99,
    category: "main-courses",
  },
  {
    id: 6,
    name: "Chocolate Lava Cake",
    price: 9.99,
    category: "desserts",
  },
  {
    id: 7,
    name: "Tiramisu",
    price: 8.99,
    category: "desserts",
  },
  {
    id: 8,
    name: "Craft Beer",
    price: 7.99,
    category: "beverages",
  },
  {
    id: 9,
    name: "Wine",
    price: 9.99,
    category: "beverages",
  },
]

export default function WaiterDashboard() {
  const [tables, setTables] = useState(initialTables)
  const [orders, setOrders] = useState(initialOrders)
  const [selectedTable, setSelectedTable] = useState<number | null>(null)
  const [newOrderItems, setNewOrderItems] = useState<
    Array<{ id: number; name: string; price: number; quantity: number }>
  >([])
  const [newOrderDialogOpen, setNewOrderDialogOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const { toast } = useToast()

  const filteredTables = tables.filter((table) => (searchQuery ? table.id.toString().includes(searchQuery) : true))

  const getTableById = (id: number) => {
    return tables.find((table) => table.id === id)
  }

  const getOrdersForTable = (tableId: number) => {
    return orders.filter((order) => order.tableId === tableId)
  }

  const handleTableStatusChange = (tableId: number, newStatus: string) => {
    setTables(tables.map((table) => (table.id === tableId ? { ...table, status: newStatus } : table)))

    toast({
      title: `Table ${tableId} status updated`,
      description: `Table status changed to ${newStatus}`,
    })
  }

  const handleOrderStatusChange = (orderId: number, newStatus: string) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order)))

    toast({
      title: `Order #${orderId} status updated`,
      description: `Order status changed to ${newStatus}`,
    })
  }

  const addItemToNewOrder = (item: (typeof menuItems)[0]) => {
    setNewOrderItems((prevItems) => {
      const existingItem = prevItems.find((i) => i.id === item.id)
      if (existingItem) {
        return prevItems.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i))
      } else {
        return [...prevItems, { ...item, quantity: 1 }]
      }
    })
  }

  const removeItemFromNewOrder = (itemId: number) => {
    setNewOrderItems((prevItems) => prevItems.filter((item) => item.id !== itemId))
  }

  const updateItemQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return

    setNewOrderItems((prevItems) =>
      prevItems.map((item) => (item.id === itemId ? { ...item, quantity: newQuantity } : item)),
    )
  }

  const createNewOrder = () => {
    if (!selectedTable) {
      toast({
        title: "No table selected",
        description: "Please select a table for this order",
        variant: "destructive",
      })
      return
    }

    if (newOrderItems.length === 0) {
      toast({
        title: "Empty order",
        description: "Please add at least one item to the order",
        variant: "destructive",
      })
      return
    }

    const newOrderId = Math.max(...orders.map((o) => o.id), 0) + 1
    const newOrder = {
      id: newOrderId,
      tableId: selectedTable,
      items: newOrderItems.map((item) => ({
        name: item.name,
        price: item.price,
        status: "pending",
        quantity: item.quantity,
      })),
      status: "pending",
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setOrders([...orders, newOrder])

    // Update table status if it was available
    setTables(
      tables.map((table) =>
        table.id === selectedTable && table.status === "available" ? { ...table, status: "occupied" } : table,
      ),
    )

    setNewOrderItems([])
    setNewOrderDialogOpen(false)

    toast({
      title: "Order created",
      description: `New order #${newOrderId} created for Table ${selectedTable}`,
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "occupied":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "preparing":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      case "ready":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300"
      case "served":
        return "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300"
      default:
        return "bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300"
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 flex flex-col">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Utensils className="h-6 w-6 text-rose-600" />
            <h1 className="text-xl font-bold">Waiter Dashboard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="icon">
              <Bell className="h-5 w-5" />
              <span className="sr-only">Notifications</span>
            </Button>
            <Link href="/staff">
              <Button variant="outline" size="icon">
                <LogOut className="h-5 w-5" />
                <span className="sr-only">Logout</span>
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Tables Section */}
          <div className="w-full md:w-1/2 lg:w-2/5">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Tables</h2>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search tables..."
                  className="pl-8 w-[200px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {filteredTables.map((table) => (
                <Card
                  key={table.id}
                  className={`cursor-pointer transition-all ${selectedTable === table.id ? "ring-2 ring-rose-500" : ""}`}
                  onClick={() => setSelectedTable(table.id)}
                >
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle>Table {table.id}</CardTitle>
                      <Badge className={getStatusColor(table.status)}>{table.status}</Badge>
                    </div>
                    <CardDescription>{table.seats} seats</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    {table.status === "occupied" && (
                      <div className="text-sm">
                        <p className="font-medium">Current Orders:</p>
                        <ul className="list-disc list-inside">
                          {getOrdersForTable(table.id).map((order) => (
                            <li key={order.id}>
                              Order #{order.id} - {order.status}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                  <CardFooter>
                    {table.status === "available" ? (
                      <Button
                        variant="outline"
                        className="w-full"
                        onClick={(e) => {
                          e.stopPropagation()
                          setSelectedTable(table.id)
                          setNewOrderDialogOpen(true)
                        }}
                      >
                        <Plus className="h-4 w-4 mr-2" /> New Order
                      </Button>
                    ) : (
                      <Select
                        onValueChange={(value) => handleTableStatusChange(table.id, value)}
                        defaultValue={table.status}
                      >
                        <SelectTrigger className="w-full" onClick={(e) => e.stopPropagation()}>
                          <SelectValue placeholder="Change status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="occupied">Occupied</SelectItem>
                          <SelectItem value="available">Available</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>

          {/* Orders Section */}
          <div className="w-full md:w-1/2 lg:w-3/5">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">
                {selectedTable ? `Orders for Table ${selectedTable}` : "All Orders"}
              </h2>
              {selectedTable && (
                <Button
                  onClick={() => {
                    setNewOrderDialogOpen(true)
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" /> New Order
                </Button>
              )}
            </div>

            {selectedTable ? (
              getOrdersForTable(selectedTable).length > 0 ? (
                <div className="space-y-4">
                  {getOrdersForTable(selectedTable).map((order) => (
                    <Card key={order.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-center">
                          <CardTitle className="flex items-center">
                            <Clock className="h-4 w-4 mr-2" />
                            Order #{order.id} - {order.time}
                          </CardTitle>
                          <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {order.items.map((item, index) => (
                            <div key={index} className="flex justify-between items-center">
                              <div>
                                <p className="font-medium">{item.name}</p>
                                <p className="text-sm text-slate-500 dark:text-slate-400">${item.price.toFixed(2)}</p>
                              </div>
                              <Badge className={getStatusColor(item.status)}>{item.status}</Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Select
                          onValueChange={(value) => handleOrderStatusChange(order.id, value)}
                          defaultValue={order.status}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Change status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="pending">Pending</SelectItem>
                            <SelectItem value="preparing">Preparing</SelectItem>
                            <SelectItem value="ready">Ready</SelectItem>
                            <SelectItem value="served">Served</SelectItem>
                          </SelectContent>
                        </Select>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-8">
                    <p className="text-slate-500 dark:text-slate-400 mb-4">No orders for this table yet</p>
                    <Button onClick={() => setNewOrderDialogOpen(true)}>
                      <Plus className="h-4 w-4 mr-2" /> Create New Order
                    </Button>
                  </CardContent>
                </Card>
              )
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-slate-500 dark:text-slate-400">Select a table to view or create orders</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* New Order Dialog */}
      <Dialog open={newOrderDialogOpen} onOpenChange={setNewOrderDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Create New Order for Table {selectedTable}</DialogTitle>
            <DialogDescription>Add items to the order from the menu below</DialogDescription>
          </DialogHeader>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium mb-2">Menu Items</h3>
              <Tabs defaultValue="appetizers" className="w-full">
                <TabsList className="mb-4 grid grid-cols-4 h-auto">
                  <TabsTrigger value="appetizers">Appetizers</TabsTrigger>
                  <TabsTrigger value="main-courses">Mains</TabsTrigger>
                  <TabsTrigger value="desserts">Desserts</TabsTrigger>
                  <TabsTrigger value="beverages">Drinks</TabsTrigger>
                </TabsList>

                <div className="max-h-[40vh] overflow-y-auto pr-2">
                  <TabsContent value="appetizers" className="space-y-2 mt-0">
                    {menuItems
                      .filter((item) => item.category === "appetizers")
                      .map((item) => (
                        <Card
                          key={item.id}
                          className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800"
                          onClick={() => addItemToNewOrder(item)}
                        >
                          <CardContent className="p-3 flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.name}</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">${item.price.toFixed(2)}</p>
                            </div>
                            <Button variant="ghost" size="icon">
                              <Plus className="h-4 w-4" />
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                  </TabsContent>

                  <TabsContent value="main-courses" className="space-y-2 mt-0">
                    {menuItems
                      .filter((item) => item.category === "main-courses")
                      .map((item) => (
                        <Card
                          key={item.id}
                          className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800"
                          onClick={() => addItemToNewOrder(item)}
                        >
                          <CardContent className="p-3 flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.name}</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">${item.price.toFixed(2)}</p>
                            </div>
                            <Button variant="ghost" size="icon">
                              <Plus className="h-4 w-4" />
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                  </TabsContent>

                  <TabsContent value="desserts" className="space-y-2 mt-0">
                    {menuItems
                      .filter((item) => item.category === "desserts")
                      .map((item) => (
                        <Card
                          key={item.id}
                          className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800"
                          onClick={() => addItemToNewOrder(item)}
                        >
                          <CardContent className="p-3 flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.name}</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">${item.price.toFixed(2)}</p>
                            </div>
                            <Button variant="ghost" size="icon">
                              <Plus className="h-4 w-4" />
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                  </TabsContent>

                  <TabsContent value="beverages" className="space-y-2 mt-0">
                    {menuItems
                      .filter((item) => item.category === "beverages")
                      .map((item) => (
                        <Card
                          key={item.id}
                          className="cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800"
                          onClick={() => addItemToNewOrder(item)}
                        >
                          <CardContent className="p-3 flex justify-between items-center">
                            <div>
                              <p className="font-medium">{item.name}</p>
                              <p className="text-sm text-slate-500 dark:text-slate-400">${item.price.toFixed(2)}</p>
                            </div>
                            <Button variant="ghost" size="icon">
                              <Plus className="h-4 w-4" />
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                  </TabsContent>
                </div>
              </Tabs>
            </div>

            <div>
              <h3 className="font-medium mb-2">Current Order</h3>
              <div className="border rounded-md p-4 max-h-[40vh] overflow-y-auto">
                {newOrderItems.length === 0 ? (
                  <p className="text-center text-slate-500 dark:text-slate-400 py-8">No items added yet</p>
                ) : (
                  <div className="space-y-4">
                    {newOrderItems.map((item) => (
                      <div key={item.id} className="flex justify-between items-center">
                        <div>
                          <p className="font-medium">{item.name}</p>
                          <p className="text-sm text-slate-500 dark:text-slate-400">${item.price.toFixed(2)} each</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => updateItemQuantity(item.id, item.quantity - 1)}
                          >
                            -
                          </Button>
                          <span>{item.quantity}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => updateItemQuantity(item.id, item.quantity + 1)}
                          >
                            +
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-red-500"
                            onClick={() => removeItemFromNewOrder(item.id)}
                          >
                            ×
                          </Button>
                        </div>
                      </div>
                    ))}

                    <div className="pt-4 border-t mt-4">
                      <div className="flex justify-between font-medium">
                        <span>Total:</span>
                        <span>
                          ${newOrderItems.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setNewOrderDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={createNewOrder} disabled={newOrderItems.length === 0}>
              Create Order
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
