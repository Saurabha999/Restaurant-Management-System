"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { format, addDays, startOfWeek, addWeeks, subWeeks, isSameDay, isToday, isBefore } from "date-fns"
import { Button } from "@/components/ui/button"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { ChevronLeft, ChevronRight, Clock, CalendarIcon, Utensils, Check } from "lucide-react"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"

// Sample data for available time slots
const timeSlots = [
  "11:00 AM",
  "11:30 AM",
  "12:00 PM",
  "12:30 PM",
  "1:00 PM",
  "1:30 PM",
  "5:00 PM",
  "5:30 PM",
  "6:00 PM",
  "6:30 PM",
  "7:00 PM",
  "7:30 PM",
  "8:00 PM",
  "8:30 PM",
]

// Sample data for table availability
// This would come from a database in a real application
const getAvailableSlots = (date: Date) => {
  // Simulate fewer slots available on weekends
  const isWeekend = date.getDay() === 0 || date.getDay() === 6
  const isFriday = date.getDay() === 5

  // Simulate some slots being booked
  if (isWeekend) {
    return timeSlots.filter((_, index) => index % 3 !== 0) // Remove every third slot
  } else if (isFriday) {
    return timeSlots.filter((_, index) => index % 2 !== 0) // Remove every second slot
  } else {
    return timeSlots // All slots available on weekdays
  }
}

export default function ReservationPage() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [selectedTime, setSelectedTime] = useState<string>("")
  const [partySize, setPartySize] = useState<string>("2")
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [specialRequests, setSpecialRequests] = useState("")
  const [calendarWeek, setCalendarWeek] = useState<Date>(startOfWeek(new Date()))
  const [reservationComplete, setReservationComplete] = useState(false)

  const { toast } = useToast()

  const availableTimeSlots = selectedDate ? getAvailableSlots(selectedDate) : []

  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date)
    setSelectedTime("") // Reset time when date changes
  }

  const nextWeek = () => {
    setCalendarWeek(addWeeks(calendarWeek, 1))
  }

  const prevWeek = () => {
    setCalendarWeek(subWeeks(calendarWeek, 1))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!selectedDate || !selectedTime || !name || !email || !phone) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    // In a real app, this would send the reservation data to a backend
    console.log({
      date: selectedDate,
      time: selectedTime,
      partySize,
      name,
      email,
      phone,
      specialRequests,
    })

    toast({
      title: "Reservation submitted!",
      description: `Your reservation for ${format(selectedDate, "MMMM d, yyyy")} at ${selectedTime} has been received.`,
    })

    // Show confirmation
    setReservationComplete(true)
  }

  const resetForm = () => {
    setSelectedDate(new Date())
    setSelectedTime("")
    setPartySize("2")
    setName("")
    setEmail("")
    setPhone("")
    setSpecialRequests("")
    setReservationComplete(false)
  }

  // Generate week view dates
  const weekDates = Array.from({ length: 7 }, (_, i) => addDays(calendarWeek, i))

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Utensils className="h-6 w-6 text-rose-600" />
            <h1 className="text-2xl font-bold">Gourmet Haven</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link
              href="/"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Home
            </Link>
            <Link
              href="/menu"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Menu
            </Link>
            <Link
              href="/about"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              About Us
            </Link>
            <Link
              href="/reservation"
              className="font-medium text-slate-900 dark:text-white hover:text-rose-600 dark:hover:text-rose-400"
            >
              Reservations
            </Link>
            <Link
              href="/staff"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Staff Portal
            </Link>
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Link href="/" className="mr-4">
            <Button variant="outline" size="icon">
              <ChevronLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h2 className="text-3xl font-bold">Make a Reservation</h2>
        </div>

        {!reservationComplete ? (
          <div className="grid md:grid-cols-2 gap-8">
            {/* Calendar and Time Selection */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Select Date & Time</CardTitle>
                  <CardDescription>Choose your preferred reservation date and time</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Calendar */}
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={prevWeek}
                        disabled={isBefore(subWeeks(calendarWeek, 1), startOfWeek(new Date()))}
                      >
                        <ChevronLeft className="h-4 w-4" />
                      </Button>
                      <h3 className="text-lg font-medium">{format(calendarWeek, "MMMM yyyy")}</h3>
                      <Button variant="outline" size="icon" onClick={nextWeek}>
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-7 gap-1 mb-4">
                      {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                        <div key={day} className="text-center text-sm font-medium text-slate-500 dark:text-slate-400">
                          {day}
                        </div>
                      ))}
                    </div>

                    <div className="grid grid-cols-7 gap-1">
                      {weekDates.map((date) => {
                        const isSelected = selectedDate && isSameDay(date, selectedDate)
                        const isPast = isBefore(date, new Date()) && !isToday(date)

                        return (
                          <Button
                            key={date.toString()}
                            variant={isSelected ? "default" : "outline"}
                            className={cn(
                              "h-12 w-full",
                              isSelected && "bg-rose-600 hover:bg-rose-700",
                              isPast && "opacity-50 cursor-not-allowed",
                            )}
                            disabled={isPast}
                            onClick={() => handleDateSelect(date)}
                          >
                            <div className="flex flex-col items-center">
                              <span className="text-xs">{format(date, "EEE")}</span>
                              <span className={cn("text-sm", isToday(date) && "font-bold")}>{format(date, "d")}</span>
                            </div>
                          </Button>
                        )
                      })}
                    </div>
                  </div>

                  {/* Full Calendar Popover */}
                  <div className="flex justify-center">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="flex items-center gap-2">
                          <CalendarIcon className="h-4 w-4" />
                          View Full Calendar
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="center">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={handleDateSelect}
                          disabled={(date) => isBefore(date, new Date()) && !isToday(date)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  {/* Time Slots */}
                  {selectedDate && (
                    <div>
                      <Label className="block mb-2">Available Times for {format(selectedDate, "MMMM d, yyyy")}</Label>
                      <div className="grid grid-cols-3 gap-2">
                        {availableTimeSlots.length > 0 ? (
                          availableTimeSlots.map((time) => (
                            <Button
                              key={time}
                              variant={selectedTime === time ? "default" : "outline"}
                              className={cn(selectedTime === time && "bg-rose-600 hover:bg-rose-700")}
                              onClick={() => setSelectedTime(time)}
                            >
                              <Clock className="h-3 w-3 mr-1" />
                              {time}
                            </Button>
                          ))
                        ) : (
                          <p className="col-span-3 text-center text-slate-500 dark:text-slate-400 py-4">
                            No available times for this date
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Party Size */}
                  <div className="space-y-2">
                    <Label htmlFor="party-size">Party Size</Label>
                    <Select value={partySize} onValueChange={setPartySize}>
                      <SelectTrigger id="party-size">
                        <SelectValue placeholder="Select party size" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((size) => (
                          <SelectItem key={size} value={size.toString()}>
                            {size} {size === 1 ? "person" : "people"}
                          </SelectItem>
                        ))}
                        <SelectItem value="11+">11+ people (large party)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Contact Information */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                  <CardDescription>Please provide your details to complete the reservation</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        placeholder="Enter your full name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address *</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter your email address"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number *</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="Enter your phone number"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="special-requests">Special Requests</Label>
                      <Textarea
                        id="special-requests"
                        placeholder="Any dietary restrictions, accessibility needs, or special occasions?"
                        value={specialRequests}
                        onChange={(e) => setSpecialRequests(e.target.value)}
                        className="min-h-[100px]"
                      />
                    </div>

                    <div className="pt-4">
                      <Button
                        type="submit"
                        className="w-full"
                        disabled={!selectedDate || !selectedTime || !name || !email || !phone}
                      >
                        Complete Reservation
                      </Button>
                    </div>
                  </form>
                </CardContent>
                <CardFooter className="text-sm text-slate-500 dark:text-slate-400">
                  <p>
                    By making a reservation, you agree to our reservation policy. We hold tables for 15 minutes past the
                    reservation time.
                  </p>
                </CardFooter>
              </Card>
            </div>
          </div>
        ) : (
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="mx-auto bg-green-100 dark:bg-green-900 w-16 h-16 rounded-full flex items-center justify-center mb-4">
                <Check className="h-8 w-8 text-green-600 dark:text-green-300" />
              </div>
              <CardTitle className="text-2xl">Reservation Confirmed!</CardTitle>
              <CardDescription>Your table has been reserved successfully</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border rounded-lg p-4 bg-slate-50 dark:bg-slate-800">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Date</p>
                    <p className="font-medium">{format(selectedDate!, "MMMM d, yyyy")}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Time</p>
                    <p className="font-medium">{selectedTime}</p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Party Size</p>
                    <p className="font-medium">
                      {partySize} {Number.parseInt(partySize) === 1 ? "person" : "people"}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Reservation Name</p>
                    <p className="font-medium">{name}</p>
                  </div>
                </div>
              </div>

              <div className="text-center space-y-2">
                <p>A confirmation email has been sent to {email}</p>
                <p>We look forward to serving you at Gourmet Haven!</p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button onClick={resetForm}>Make Another Reservation</Button>
            </CardFooter>
          </Card>
        )}

        {/* Restaurant Information */}
        <div className="mt-12 bg-white dark:bg-slate-800 rounded-lg p-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Reservation Information</h3>
              <div className="space-y-4 text-slate-700 dark:text-slate-300">
                <p>
                  Reservations are recommended for dinner service and weekends. For parties larger than 10, please
                  contact us directly at (555) 123-4567.
                </p>
                <p>
                  We hold reservations for 15 minutes past the reservation time. After that, tables may be released to
                  accommodate waiting guests.
                </p>
                <p>For special events or private dining inquiries, please email us at events@gourmethaven.com.</p>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Hours & Location</h3>
              <div className="space-y-4 text-slate-700 dark:text-slate-300">
                <p>
                  <span className="font-medium">Address:</span>
                  <br />
                  123 Culinary Street
                  <br />
                  Foodie District
                  <br />
                  Cityville, CV 12345
                </p>
                <p>
                  <span className="font-medium">Hours:</span>
                  <br />
                  Monday - Thursday: 11am - 10pm
                  <br />
                  Friday - Saturday: 11am - 11pm
                  <br />
                  Sunday: 10am - 9pm
                </p>
                <p>
                  <span className="font-medium">Phone:</span> (555) 123-4567
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-slate-900 text-white py-12 mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Utensils className="h-6 w-6 text-rose-400" />
                <h2 className="text-xl font-bold">Gourmet Haven</h2>
              </div>
              <p className="text-slate-300 mb-4">
                123 Culinary Street
                <br />
                Foodie District
                <br />
                Cityville, CV 12345
              </p>
              <p className="text-slate-300">
                Phone: (555) 123-4567
                <br />
                Email: info@gourmethaven.com
              </p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Hours</h3>
              <p className="text-slate-300 mb-2">Monday - Thursday: 11am - 10pm</p>
              <p className="text-slate-300 mb-2">Friday - Saturday: 11am - 11pm</p>
              <p className="text-slate-300">Sunday: 10am - 9pm</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
              <div className="space-y-2">
                <Link href="/" className="block text-slate-300 hover:text-white">
                  Home
                </Link>
                <Link href="/menu" className="block text-slate-300 hover:text-white">
                  Menu
                </Link>
                <Link href="/about" className="block text-slate-300 hover:text-white">
                  About Us
                </Link>
                <Link href="/reservation" className="block text-slate-300 hover:text-white">
                  Reservations
                </Link>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>© {new Date().getFullYear()} Gourmet Haven Restaurant. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
