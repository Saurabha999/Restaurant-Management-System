import { Skeleton } from "@/components/ui/skeleton"

export default function Loading() {
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Skeleton className="h-6 w-6 rounded-full" />
            <Skeleton className="h-8 w-32" />
          </div>
          <nav className="hidden md:flex space-x-6">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-6 w-20" />
            ))}
          </nav>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Skeleton className="h-10 w-10 rounded-md mr-4" />
          <Skeleton className="h-10 w-64" />
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Skeleton className="h-[600px] w-full rounded-lg" />
          <Skeleton className="h-[600px] w-full rounded-lg" />
        </div>

        <Skeleton className="h-[300px] w-full rounded-lg mt-12" />
      </main>

      <Skeleton className="h-[300px] w-full mt-12" />
    </div>
  )
}
