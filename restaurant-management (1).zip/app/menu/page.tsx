"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ChevronLeft, Home, Plus, ShoppingCart, Utensils } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

// Menu data
const menuCategories = [
  { id: "appetizers", name: "Appetizers" },
  { id: "main-courses", name: "Main Courses" },
  { id: "desserts", name: "Desserts" },
  { id: "beverages", name: "Beverages" },
]

const menuItems = [
  {
    id: 1,
    name: "Bruschetta",
    description: "Toasted bread topped with tomatoes, garlic, and fresh basil",
    price: 8.99,
    category: "appetizers",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    name: "Calamari",
    description: "Crispy fried squid served with marinara sauce",
    price: 12.99,
    category: "appetizers",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    name: "Grilled Salmon",
    description: "Fresh salmon fillet with lemon butter sauce and seasonal vegetables",
    price: 24.99,
    category: "main-courses",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 4,
    name: "Beef Tenderloin",
    description: "Prime beef tenderloin with red wine reduction and truffle mashed potatoes",
    price: 32.99,
    category: "main-courses",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 5,
    name: "Mushroom Risotto",
    description: "Creamy arborio rice with wild mushrooms and parmesan",
    price: 18.99,
    category: "main-courses",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 6,
    name: "Chocolate Lava Cake",
    description: "Warm chocolate cake with a molten center, served with vanilla ice cream",
    price: 9.99,
    category: "desserts",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 7,
    name: "Tiramisu",
    description: "Classic Italian dessert with layers of coffee-soaked ladyfingers and mascarpone cream",
    price: 8.99,
    category: "desserts",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 8,
    name: "Craft Beer",
    description: "Selection of local craft beers",
    price: 7.99,
    category: "beverages",
    image: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 9,
    name: "Wine",
    description: "Glass of house red or white wine",
    price: 9.99,
    category: "beverages",
    image: "/placeholder.svg?height=200&width=300",
  },
]

export default function MenuPage() {
  const [cart, setCart] = useState<Array<{ item: (typeof menuItems)[0]; quantity: number }>>([])
  const [tableNumber, setTableNumber] = useState("")
  const [orderDialogOpen, setOrderDialogOpen] = useState(false)
  const { toast } = useToast()

  const addToCart = (item: (typeof menuItems)[0]) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((cartItem) => cartItem.item.id === item.id)
      if (existingItem) {
        return prevCart.map((cartItem) =>
          cartItem.item.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem,
        )
      } else {
        return [...prevCart, { item, quantity: 1 }]
      }
    })

    toast({
      title: "Added to order",
      description: `${item.name} has been added to your order.`,
      duration: 2000,
    })
  }

  const removeFromCart = (itemId: number) => {
    setCart((prevCart) => prevCart.filter((cartItem) => cartItem.item.id !== itemId))
  }

  const updateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return

    setCart((prevCart) =>
      prevCart.map((cartItem) => (cartItem.item.id === itemId ? { ...cartItem, quantity: newQuantity } : cartItem)),
    )
  }

  const getTotalPrice = () => {
    return cart.reduce((total, cartItem) => total + cartItem.item.price * cartItem.quantity, 0)
  }

  const placeOrder = () => {
    if (!tableNumber) {
      toast({
        title: "Table number required",
        description: "Please enter your table number to place an order.",
        variant: "destructive",
      })
      return
    }

    // In a real app, this would send the order to the backend
    console.log("Order placed:", { tableNumber, items: cart, total: getTotalPrice() })

    toast({
      title: "Order placed successfully!",
      description: `Your order for table ${tableNumber} has been sent to the kitchen.`,
    })

    setCart([])
    setTableNumber("")
    setOrderDialogOpen(false)
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <header className="bg-white dark:bg-slate-950 shadow-sm">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Utensils className="h-6 w-6 text-rose-600" />
            <h1 className="text-2xl font-bold">Gourmet Haven</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link
              href="/"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Home
            </Link>
            <Link
              href="/menu"
              className="font-medium text-slate-900 dark:text-white hover:text-rose-600 dark:hover:text-rose-400"
            >
              Menu
            </Link>
            <Link
              href="/staff"
              className="font-medium text-slate-600 dark:text-slate-300 hover:text-rose-600 dark:hover:text-rose-400"
            >
              Staff Portal
            </Link>
          </nav>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="icon" asChild>
              <Link href="/">
                <Home className="h-5 w-5" />
                <span className="sr-only">Home</span>
              </Link>
            </Button>
            <Dialog open={orderDialogOpen} onOpenChange={setOrderDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  {cart.length > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0">
                      {cart.reduce((total, item) => total + item.quantity, 0)}
                    </Badge>
                  )}
                  <span className="sr-only">View Order</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Your Order</DialogTitle>
                  <DialogDescription>Review your order before placing it.</DialogDescription>
                </DialogHeader>
                <div className="max-h-[50vh] overflow-y-auto py-4">
                  {cart.length === 0 ? (
                    <p className="text-center text-slate-500 dark:text-slate-400">Your order is empty</p>
                  ) : (
                    <div className="space-y-4">
                      {cart.map((cartItem) => (
                        <div key={cartItem.item.id} className="flex justify-between items-center">
                          <div>
                            <p className="font-medium">{cartItem.item.name}</p>
                            <p className="text-sm text-slate-500 dark:text-slate-400">
                              ${cartItem.item.price.toFixed(2)} each
                            </p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => updateQuantity(cartItem.item.id, cartItem.quantity - 1)}
                            >
                              -
                            </Button>
                            <span>{cartItem.quantity}</span>
                            <Button
                              variant="outline"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => updateQuantity(cartItem.item.id, cartItem.quantity + 1)}
                            >
                              +
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-red-500"
                              onClick={() => removeFromCart(cartItem.item.id)}
                            >
                              ×
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                {cart.length > 0 && (
                  <>
                    <div className="flex justify-between items-center py-4 font-medium">
                      <span>Total:</span>
                      <span>${getTotalPrice().toFixed(2)}</span>
                    </div>
                    <div className="space-y-2 py-4">
                      <Label htmlFor="table-number">Table Number</Label>
                      <Input
                        id="table-number"
                        value={tableNumber}
                        onChange={(e) => setTableNumber(e.target.value)}
                        placeholder="Enter your table number"
                      />
                    </div>
                  </>
                )}
                <DialogFooter>
                  <Button variant="outline" onClick={() => setOrderDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={placeOrder} disabled={cart.length === 0}>
                    Place Order
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-8">
          <Link href="/" className="mr-4">
            <Button variant="outline" size="icon">
              <ChevronLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h2 className="text-3xl font-bold">Our Menu</h2>
        </div>

        <Tabs defaultValue="appetizers" className="w-full">
          <TabsList className="mb-8 flex flex-wrap h-auto">
            {menuCategories.map((category) => (
              <TabsTrigger key={category.id} value={category.id} className="flex-grow">
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {menuCategories.map((category) => (
            <TabsContent key={category.id} value={category.id} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {menuItems
                  .filter((item) => item.category === category.id)
                  .map((item) => (
                    <Card key={item.id} className="overflow-hidden">
                      <div className="relative h-48">
                        <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                      </div>
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <CardTitle>{item.name}</CardTitle>
                          <div className="font-bold text-rose-600">${item.price.toFixed(2)}</div>
                        </div>
                        <CardDescription>{item.description}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button onClick={() => addToCart(item)} className="w-full">
                          <Plus className="h-4 w-4 mr-2" /> Add to Order
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </main>
    </div>
  )
}
